#!/usr/bin/env python3
"""
Comprehensive SPIQA Test-A runner
复用 SPIQA_test/test_spiqa_comprehensive.py 中的 ComprehensiveSPIQATester，
将数据与图片根目录切换为 Test-A 并保持全架构统计流程。
"""

import os
import json
import asyncio
import base64
import re
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional

# 复用现有的综合测试器（包含多模态/视觉模型调用与完整统计）
# 兼容直接脚本运行与包内相对导入
try:
    from SPIQA_test.test_spiqa_comprehensive import ComprehensiveSPIQATester  # type: ignore
except Exception:
    import sys
    sys.path.append(str(Path(__file__).parent))
    from test_spiqa_comprehensive import ComprehensiveSPIQATester  # type: ignore


DATASET_JSON = Path("dataset/test-A/SPIQA_testA.json")
IMAGES_ROOT = Path("dataset/test-A/SPIQA_testA_Images")


async def run() -> None:
    print("🚀 开始 SPIQA Test-A（完整架构）...")

    if not DATASET_JSON.exists():
        print(f"❌ 数据集不存在: {DATASET_JSON}")
        return

    with DATASET_JSON.open("r", encoding="utf-8") as f:
        data: Dict[str, Any] = json.load(f)

    print(f"📊 总论文数: {len(data)}")

    image_root = str(IMAGES_ROOT) if IMAGES_ROOT.exists() else ""
    if image_root:
        print(f"🖼️ 图片目录: {image_root}")
    else:
        print("⚠️ 未找到图片目录，将以文本模式作答（准确率会受到影响）")

    tester = ComprehensiveSPIQATester(image_root)

    # Prefer Azure Vision if configured
    def build_azure_vision_func() -> Optional[Any]:
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").rstrip("/")
        api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
        api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01")
        deployment = os.getenv("AZURE_OPENAI_VISION_DEPLOYMENT", "")
        if not (endpoint and api_key and deployment):
            return None
        url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"

        async def vision_func(prompt=None, system_prompt=None, history_messages=[], image_data=None, messages=None, **kwargs):
            if messages is None:
                content = []
                if prompt:
                    content.append({"type": "text", "text": prompt})
                if image_data:
                    content.append({"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_data}"}})
                messages = []
                if system_prompt:
                    messages.append({"role": "system", "content": system_prompt})
                messages.append({"role": "user", "content": content})

            payload = {"messages": messages, "temperature": 0.0, "top_p": 0.1, "max_tokens": 1024}
            import urllib.request as _r, json as _j
            # Build SSL context with certifi if available to avoid SSL verify errors
            try:
                import ssl, certifi
                _ctx = ssl.create_default_context(cafile=certifi.where())
            except Exception:
                try:
                    import ssl
                    _ctx = ssl.create_default_context()
                    _ctx.check_hostname = False
                    _ctx.verify_mode = getattr(ssl, 'CERT_NONE', 0)
                except Exception:
                    _ctx = None
            req = _r.Request(url, data=_j.dumps(payload).encode("utf-8"), headers={"Content-Type": "application/json", "api-key": api_key})
            try:
                def _do():
                    if _ctx is not None:
                        resp_ctx = _r.urlopen(req, timeout=240, context=_ctx)
                    else:
                        resp_ctx = _r.urlopen(req, timeout=240)
                    with resp_ctx as resp:
                        return _j.loads(resp.read().decode("utf-8"))
                resp = await asyncio.to_thread(_do)
                ch = resp.get("choices", [])
                return (ch[0].get("message", {}).get("content", "").strip()) if ch else ""
            except Exception as e:
                print(f"Azure Vision 调用失败: {e}")
                return ""
        return vision_func

    azure_vision_func = build_azure_vision_func()
    use_vision_func = azure_vision_func if azure_vision_func else tester.vision_func

    # --- helpers for improved accuracy ---
    def normalize_text(s: str) -> str:
        return re.sub(r"\s+", " ", (s or "").strip().lower())

    _LETTER_PATTERN = re.compile(r"\b([A-E])\b", re.IGNORECASE)

    def extract_option_letter(text: str) -> str:
        if not text:
            return ""
        m = _LETTER_PATTERN.search(text.strip())
        return m.group(1).upper() if m else ""

    def detect_is_multiple_choice(question_text: str) -> bool:
        if not question_text:
            return False
        return bool(re.search(r"\b[A-E]\s*[\)\.]", question_text))

    def score_caption_keywords(question: str, caption: str) -> int:
        """Very simple keyword overlap score between question and caption."""
        q_words = set(re.findall(r"[a-zA-Z0-9]+", (question or "").lower()))
        c_words = set(re.findall(r"[a-zA-Z0-9]+", (caption or "").lower()))
        if not q_words or not c_words:
            return 0
        return len(q_words.intersection(c_words))

    def score_filename_pattern(question: str, fig_id: str) -> int:
        """Boost score if question mentions Table/Figure numbers matching fig_id."""
        q = (question or "").lower()
        bonus = 0
        m = re.search(r"(table|figure)\s*(\d+)", q)
        if m:
            kind = m.group(1)
            num = m.group(2)
            if kind == 'table' and ('table' in fig_id.lower()) and num in fig_id:
                bonus += 5
            if kind == 'figure' and ('figure' in fig_id.lower()) and num in fig_id:
                bonus += 5
        # also boost if fig_id contains the paper_id prefix reference pattern already selected
        return bonus

    max_papers = int(os.getenv("TESTA_MAX_PAPERS", "0") or 0)
    max_images_per_q = int(os.getenv("TESTA_MAX_IMAGES_PER_Q", "3") or 3)

    all_results: Dict[str, Any] = {}
    processed_count = 0
    failed_count = 0
    correct_count = 0

    similarity_scores = []
    phrase_overlaps = []
    question_types: Dict[str, Dict[str, int]] = {}

    def _pick(d: Dict[str, Any], keys):
        for k in keys:
            if k in d and isinstance(d[k], str) and d[k].strip():
                return d[k]
        return ""

    processed_papers = 0
    for paper_id, paper_content in data.items():
        print(f"\n🔬 处理论文: {paper_id}")
        try:
            figures_data = paper_content.get("all_figures") or paper_content.get("all_figures_tables") or {}
            qa_list = paper_content.get("qa")
            if not isinstance(qa_list, list):
                # 兼容旧格式：成对数组
                questions = paper_content.get("question") or []
                answers = paper_content.get("answer") or []
                qa_list = [
                    {"question": questions[i], "answer": answers[i]} for i in range(min(len(questions), len(answers)))
                ]

            print(f"  📝 Questions: {len(qa_list)}")
            print(f"  🖼️  Figures: {len(figures_data)}")

            paper_correct = 0
            paper_total = 0

            for q_idx, qa in enumerate(qa_list):
                question_text = _pick(qa, ["question", "Q", "q", "prompt"]) or str(qa)
                answer_text = _pick(qa, ["answer", "A", "ans", "gt", "ground_truth"]) or ""
                reference = _pick(qa, ["reference", "figure", "image", "ref"]) or ""
                q_type = qa.get("question_type") or qa.get("type") or ""

                # 选图策略：优先 reference；若无，则按 caption 关键词与题干重叠排序，取前K
                candidate_figs: List[Tuple[str, int]] = []
                if isinstance(figures_data, dict):
                    if reference and reference in figures_data:
                        candidate_figs.append((reference, 9999))
                    else:
                        for fig_id, fig_info in figures_data.items():
                            cap = fig_info.get("caption", "") if isinstance(fig_info, dict) else str(fig_info)
                            score = score_caption_keywords(question_text, cap) + score_filename_pattern(question_text, fig_id)
                            candidate_figs.append((fig_id, score))
                        candidate_figs.sort(key=lambda x: x[1], reverse=True)
                # 回退策略：仅选择 1 张（reference 优先）
                selected_figs = [fid for fid, _ in candidate_figs[:1] if fid]

                # 加载所选图片（路径: image_root/paper_id/fig_id）
                images_b64: List[str] = []
                if image_root and selected_figs:
                    for fid in selected_figs:
                        img_path = Path(image_root) / paper_id / fid
                        if img_path.exists():
                            try:
                                images_b64.append(base64.b64encode(img_path.read_bytes()).decode("utf-8"))
                            except Exception:
                                pass

                # 两阶段：VLM结构化抽取(JSON) -> 需要时再LLM推理
                ans = ""
                is_mc = detect_is_multiple_choice(question_text)
                if images_b64:
                    extraction_system = (
                        "你是图表/表格读取器。严格输出 JSON，不要额外文本。字段: "
                        "{caption:string, key_values:object, trends:string, cells:object, units:string, final_answer:string}."
                    )
                    extraction_user = (
                        f"Question: {question_text}\n先从图片中抽取关键信息并用 JSON 返回。如果能直接确定答案，请放在 final_answer。"
                    )
                    user_content = [{"type": "text", "text": extraction_user}]
                    for b64 in images_b64:
                        user_content.append({
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{b64}"}
                        })
                    extract_msgs = [
                        {"role": "system", "content": extraction_system},
                        {"role": "user", "content": user_content},
                    ]
                    extraction = await use_vision_func(prompt=None, messages=extract_msgs)
                    parsed_extract = None
                    try:
                        parsed_extract = json.loads(extraction)
                    except Exception:
                        parsed_extract = None
                    # 若整体多图抽取失败，尝试逐图抽取并合并
                    # 回退：不做多图合并，保持单图
                    if isinstance(parsed_extract, dict) and parsed_extract.get("final_answer"):
                        ans = str(parsed_extract.get("final_answer"))
                    else:
                        # 回退：使用文本 LLM 进行基于抽取结果的二次推理（此前更稳定）
                        reasoning_system = (
                            "你是一个严格的科学图表阅读助手。\n"
                            "- 若题为选择题，只输出最终选项字母（A/B/C/D/E）。\n"
                            "- 若为开放题，输出简洁数值/结论，保留单位。"
                        )
                        reasoning_prompt = f"已抽取的图表信息(JSON):\n{extraction}\n\n问题: {question_text}\n仅输出答案。"
                        ans = await tester.llm_func(reasoning_prompt, system_prompt=reasoning_system)
                    # 若仍为空，再直接请求视觉模型给出最终答案
                    if not ans:
                        direct_system = (
                            "你是一个严格的科学图表阅读助手。\n"
                            "- 若题为选择题，只输出最终选项字母（A/B/C/D/E）。\n"
                            "- 若为开放题，输出简洁数值/结论，保留单位。"
                        )
                        direct_user = [{"type": "text", "text": f"Question: {question_text}\n仅输出答案。"}]
                        for b64 in images_b64:
                            direct_user.append({"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}})
                        direct_msgs = [
                            {"role": "system", "content": direct_system},
                            {"role": "user", "content": direct_user}
                        ]
                        ans = await use_vision_func(prompt=None, messages=direct_msgs)
                    # 再次兜底：若仍为空，用文本LLM作答
                    if not ans:
                        ans = await tester.llm_func(
                            f"问题: {question_text}\n请基于图表抽取信息回答，若无法判断则输出‘无法判断’。仅输出答案。",
                            system_prompt="你是严格的科学图表阅读助手。"
                        )
                else:
                    # 无图时，文本模式
                    ans = await tester.llm_func(
                        f"Question: {question_text}\nAnswer concisely.",
                        system_prompt="You are a precise QA assistant. Output only the final answer."
                    )

                # 本地评测（字母优先，随后相似度与数值宽容）
                pred_letter = extract_option_letter(ans)
                gt_letter = extract_option_letter(answer_text)
                norm_pred = normalize_text(ans)
                norm_gt = normalize_text(answer_text)
                similarity_score = tester.similarity(norm_pred, norm_gt)
                # phrase overlap 复用 tester 的方法（通过其简单短语抽取不可用；退化为相似度）
                phrase_overlap = similarity_score
                # 数值宽容比较（±5% 或绝对差 < 0.02）
                def _nums(s: str) -> List[float]:
                    return [float(x) for x in re.findall(r"[-+]?[0-9]*\.?[0-9]+", s)]
                nums_pred = _nums(norm_pred)
                nums_gt = _nums(norm_gt)
                numeric_match = False
                if nums_pred and nums_gt:
                    for ap in nums_pred:
                        for ag in nums_gt:
                            if ag == 0:
                                if abs(ap - ag) < 0.02:
                                    numeric_match = True
                                    break
                            else:
                                if abs(ap - ag) / abs(ag) <= 0.05:
                                    numeric_match = True
                                    break
                        if numeric_match:
                            break
                contains = (norm_gt and norm_gt in norm_pred) or (norm_pred and norm_pred in norm_gt)
                is_correct = similarity_score >= 0.6 or numeric_match or contains
                if is_mc and pred_letter and gt_letter:
                    is_correct = (pred_letter == gt_letter)

                evaluation = {
                    "similarity_score": similarity_score,
                    "phrase_overlap": phrase_overlap,
                    "is_correct": is_correct
                }

                res = {
                    "paper_id": paper_id,
                    "question_index": q_idx,
                    "question": question_text,
                    "ground_truth": answer_text,
                    "predicted_answer": ans,
                    "reference": reference,
                    "question_type": q_type or ("multiple_choice" if any(x in question_text for x in ["A)", "B)", "C)", "D)"]) else "open_ended"),
                    "evaluation": evaluation,
                }
                qid = f"{paper_id}_q{q_idx}"
                all_results[qid] = res

                processed_count += 1
                paper_total += 1
                similarity_scores.append(evaluation.get("similarity_score", 0.0))
                phrase_overlaps.append(evaluation.get("phrase_overlap", 0.0))
                if evaluation.get("is_correct"):
                    correct_count += 1
                    paper_correct += 1
                qt = res.get("question_type", "Unknown")
                if qt not in question_types:
                    question_types[qt] = {"total": 0, "correct": 0}
                question_types[qt]["total"] += 1
                if evaluation.get("is_correct"):
                    question_types[qt]["correct"] += 1

            with open("spiqa_testa_full_results.json", "w", encoding="utf-8") as f:
                json.dump(all_results, f, ensure_ascii=False, indent=2)
            print(f"  ✅ 完成: {paper_correct}/{paper_total} 正确")

        except Exception as exc:
            print(f"  ❌ 处理论文 {paper_id} 时出错: {exc}")
            failed_count += 1

        processed_papers += 1
        if max_papers > 0 and processed_papers >= max_papers:
            print(f"⏹️ 已处理前 {max_papers} 篇论文，提前停止用于小样本验证。")
            break

    # 汇总
    overall_accuracy = (correct_count / processed_count) if processed_count else 0.0
    avg_similarity = (sum(similarity_scores) / len(similarity_scores)) if similarity_scores else 0.0
    avg_phrase_overlap = (sum(phrase_overlaps) / len(phrase_overlaps)) if phrase_overlaps else 0.0

    print("\n" + "=" * 60)
    print("📈 Test-A（完整架构）最终结果")
    print("=" * 60)
    print(f"📊 总问题数: {processed_count + failed_count}")
    print(f"✅ 成功处理: {processed_count}")
    print(f"❌ 失败: {failed_count}")
    print(f"🎯 正确回答: {correct_count}")
    print(f"📈 总体准确率: {overall_accuracy:.3f} ({correct_count}/{processed_count})")
    print(f"📊 平均相似度: {avg_similarity:.3f}")
    print(f"📊 平均短语重叠: {avg_phrase_overlap:.3f}")
    print("\n📋 问题类型表现:")
    for q_type, stats in question_types.items():
        total = stats.get("total", 0)
        correct = stats.get("correct", 0)
        acc = (correct / total) if total else 0.0
        print(f"  {q_type}: {acc:.3f} ({correct}/{total})")

    with open("spiqa_testa_full_results_final.json", "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print("\n💾 已保存: spiqa_testa_full_results_final.json")

    # 可选：限制前若干论文用于快验（通过环境变量）
    if max_papers > 0:
        print(f"⚠️ 注意：设置了 TESTA_MAX_PAPERS={max_papers}，建议用于小样本验证。")


if __name__ == "__main__":
    asyncio.run(run())


